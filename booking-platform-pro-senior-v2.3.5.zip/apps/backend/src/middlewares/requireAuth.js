module.exports = require("./requireAuthPage");
