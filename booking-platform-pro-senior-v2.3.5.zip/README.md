# Booking Platform (refactor pro-senior)

- Backend: apps/backend/src
- Front statique: apps/frontend/public (copié du zip)
- Data: data/bookings.json

## Run
cd apps/backend
npm i
npm run dev
